package com.telefonica;

import java.util.Arrays;
import java.util.Iterator;

public class AppMain {

	public static void main(String[] args) {
		// Declarar una variable de tipo array
		int num;
		int numeros[];
		// String [] nombres;
		// char[] letras;
		
		// Crear el array
		numeros = new int[4];
		
		// Asignar valores al array
		numeros[0] = 6;
		numeros[1] = 9;
		numeros[2] = 4;
		numeros[3] = 1;
		
		// Todo en uno
		String [] nombres = {"Marta", "Lola", "Antonio", "Luis", "Alfredo"};
		
		// for tradicional
		for(int i=0; i<numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		// for-each
		for (String name : nombres) {
			System.out.println(name);
		}
		
		System.out.println(nombres);
		System.out.println(Arrays.toString(nombres));
		
		// Arrays de varias dimensiones
		int matriz[][] = new int[2][3];   // 2 filas x 3 columnas
		matriz[0][0] = 9;
		matriz[0][1] = 4;
		matriz[0][2] = 3;
		matriz[1][0] = 7;
		matriz[1][1] = 5;
		matriz[1][2] = 1;
		
		for(int fila=0; fila < matriz.length; fila++) {
			for(int col=0; col<matriz[fila].length; col++) {
				System.out.print(matriz[fila][col] + "\t");
			}
			System.out.println();
		}
		
		for (int[] fila : matriz) {
			for (int dato: fila) {
				System.out.print(dato + "\t");
			}
			System.out.println();
		}
		
		System.out.println(Arrays.deepToString(matriz));
	}

}
