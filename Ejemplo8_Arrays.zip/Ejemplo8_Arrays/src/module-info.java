module Ejemplo8_Arrays {
}