package com.telefonica.models;

public interface ProductoVenta {
	
	// todas las propiedades que declare se consideran constantes
	
	// todos los metodos se consideran publicos y abstractos
	public void setPrecio(double precio);
	public abstract void setCodigo(String codigo);
	
	double getPrecio();
	abstract String getCodigo();
	

}
