package com.telefonica.models;

public class Perro extends Animal implements ProductoVenta{
	
	private double precio;
	private String codigo;
	
	private boolean vacunado;
	private char sexo;
	
	public Perro() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Perro(String nombre, int edad, double precio, String codigo, boolean vacunado, char sexo) {
		super(nombre, edad);
		this.precio = precio;
		this.codigo = codigo;
		this.vacunado = vacunado;
		this.sexo = sexo;
	}



	@Override
	public void setPrecio(double precio) {
		this.precio = precio;		
	}

	@Override
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Override
	public double getPrecio() {
		return precio;
	}

	@Override
	public String getCodigo() {
		return codigo;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}



	@Override
	public String toString() {
		return "Perro [precio=" + precio + ", codigo=" + codigo + ", vacunado=" + vacunado + ", sexo=" + sexo
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
