package com.telefonica;

import com.telefonica.models.Perro;

public class AppMain {
	
	public static void main(String[] args) {
		
		Perro perro = new Perro("Fifi", 2, 299.95, "Pe-001", true, 'H');
		System.out.println(perro);
		
	}

}
