package com.telefonica;

public class AppMain {

	// main + ctrl + space
	public static void main(String[] args) {
		
		// Operadores aritmeticos
		int num1 = 7;
		int num2 = 3;
		
		System.out.println("Suma: " + (num1 + num2) );
		System.out.println("Resta: " + (num1 - num2) );
		System.out.println("Multiplicacion: " + (num1 * num2) );
		System.out.println("Division: " + (num1 / num2) );
		System.out.println("Modulo: " + (num1 % num2) );
		
		// Operadores de comparacion
		boolean mayor = num1 > num2;
		System.out.println("Es mayor el numero 1? " + mayor);
		System.out.println("Es menor el numero 1? " + (num1 < num2));
		System.out.println("Es mayor o igual el numero 1? " + (num1 >= num2));
		System.out.println("Es menor o igual el numero 1? " + (num1 <= num2));
		System.out.println("Son iguales? " + (num1 == num2));
		System.out.println("Son diferentes? " + (num1 != num2));
		
		// Operadores de asignacion
		num1 += 5;    // num1 = num1 + 5;
		num1 -= 5;    // num1 = num1 - 5;
		num1 *= 5;    // num1 = num1 * 5;
		num1 /= 5;    // num1 = num1 / 5;
		num1 %= 5;    // num1 = num1 % 5;
		
		// Incrementos y decrementos
		num2++;  // num2 +=1   num2 = num2 + 1;
		num2--;  // num2 -=1   num2 = num2 - 1;
		
		num2 = 10;
		//int resultado = num2++;   // post-incremento   1ª asigna, 2ª incrementa
		int resultado = ++num2;		  // pre-incremento    1º incrementa, 2º asigna
		System.out.println("num2 " + num2 + ", resultado " + resultado);
		
		// Operadores logicos
		System.out.println("num1 es mayor que num2 y num2 = 10? " + 
				((num1 > num2) && (num2 == 10)) );
	}

}
