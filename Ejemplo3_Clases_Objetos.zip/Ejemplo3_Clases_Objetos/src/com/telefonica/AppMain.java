package com.telefonica;
 
// En Java, cuando utilizo clases de otros paquetes hay que importarlas
import com.telefonica.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear objetos o instancias de Empleado
		Empleado empleado1 =  new Empleado();
		empleado1.numEmpleado = 1;
		empleado1.nombre = "Juan";
		empleado1.sueldo = 54000;
		
		empleado1.mostrarDetalle();
		System.out.println(empleado1.verNombre());
		empleado1.cambiarSueldo(56000);
		empleado1.mostrarDetalle();
		
		Empleado empleado2 = new Empleado(2, "Maria", 63000);
		empleado2.mostrarDetalle();
		
	}

}
