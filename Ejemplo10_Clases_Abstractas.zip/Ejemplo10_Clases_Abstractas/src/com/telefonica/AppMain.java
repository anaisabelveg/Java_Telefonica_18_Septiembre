package com.telefonica;

import com.telefonica.models.Triangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Triangulo triangulo = new Triangulo(10, 20, 45, 72);
		System.out.println(triangulo);
		System.out.println("Area: " + triangulo.calcularArea());

	}

}
