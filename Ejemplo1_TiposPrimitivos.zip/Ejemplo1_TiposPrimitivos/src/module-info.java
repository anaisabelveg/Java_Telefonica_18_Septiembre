module Ejemplo1_TiposPrimitivos {
}