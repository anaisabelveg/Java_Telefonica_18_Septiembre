package com.telefonica;

public class AppMain {

	// Marca el punto de entrada a la aplicacion
	public static void main(String[] args) {
		
		/*
		 * Ejemplo para  mostrar los tipos primitivos
		 */
		
		// Numericos enteros
		byte numByte = (byte)8;   		// 8 bits
		short numShort = (short)250;  	// 16 bits
		int numInt = 1234567; 			// 32 bits  (defecto)
		long numLong = 76567887654L; 	// 64 bits sufijo l ó L
		
		// Numericos reales
		float numFloat = 4.12F;			// 32 bits  sufijo f ó F
		double numDouble = 6.55676;	    // 64 bits (defecto)
		
		// boolean: true y false 
		boolean incidencia = false;
		boolean soltero = true;
		
		// Caracter: 'caracter'
		char letra = 'r';
		char salto = '\n';
		
		// String es una clase, no un tipo primitivo
		// Las clases se escriben con la primera letra en mayusculas.
		// Las cadenas de texto van entre comillas dobles
		String cadena = "Bienvenidos al curso de Java";
		
		// syso + ctrl + space
		System.out.println("NumByte: " + numByte);
		System.out.println("NumShort: " + numShort);
		System.out.println("NumInt: " + numInt);
		System.out.println("NumLong: " + numLong);
		System.out.println("NumFloat: " + numFloat);
		System.out.println("NumDouble: " + numDouble);
		System.out.println("Incidencia: " + incidencia);
		System.out.println("Letra: " + letra);
		System.out.println("Cadena: " + cadena);

	}  // Fin del metodo main

}  // Fin de la clase
