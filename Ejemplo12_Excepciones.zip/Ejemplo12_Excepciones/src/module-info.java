module Ejemplo12_Excepciones {
}