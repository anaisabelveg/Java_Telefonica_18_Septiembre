package com.telefonica;

import java.util.Scanner;

import com.telefonica.utils.NegativoException;

public class AppMain {

	public static void main(String[] args) throws NegativoException {

		String[] datos = { "1", "dos", "3", "4", "5" };
		int suma = 0;

		for (String dato : datos) {
			try {
				int num = Integer.parseInt(dato);
				suma += num;
			} catch (Exception e) {
				System.out.println("Ha ocurrido un error " + e.getMessage());
				e.printStackTrace();
			}
		}

		System.out.println("Suma: " + suma);
		
		
		// Pedir al usuario que introduzca su edad
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce tu edad: ");
		int edad = sc.nextInt();
		
		if (edad < 0) {
			// Lanzar una excepcion
			throw new NegativoException("La edad no puede ser negativa");
		}
		

	}

}
