package com.telefonica.utils;

/*
 * Las excepciones en Java pueden ser de dos tipos:
 * 	checked: me obliga a manejar la excepcion (Exception)
 *  unchecked: no me obliga a manejar la excepcion (RuntimeException)
 * */
public class NegativoException extends Exception{
	
	public NegativoException(String mensaje) {
		super(mensaje);
	}

}
