package com.telefonica;

import java.util.Scanner;

public class Bucle_Do_While {
	
	public static void main(String[] args) {
		
		// Solicitar el pw al usuario hasta que adivine que es curso
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce pw:");
		String pw = sc.next();
		
		while(! "curso".equals(pw)) {
			System.out.println("Pw incorrecta, vuelve a intentarlo");
			System.out.println("Introduce pw:");
			pw = sc.next();
		} 
		
		System.out.println("Acertaste");
		
		sc.close();
	}

}
