package com.telefonica;

import java.util.Scanner;

public class Bucle_While {
	
	public static void main(String[] args) {
		
		// Solicitar el pw al usuario hasta que adivine que es curso
		Scanner sc = new Scanner(System.in);
		String pw = "";
		
		do {
			System.out.println("Introduce pw:");
			pw = sc.next();
		} while(! "curso".equals(pw));
		
		System.out.println("Acertaste");
		
		sc.close();
	}

}
