package com.telefonica;

import java.util.Scanner;

public class Switch_Case {

	public static void main(String[] args) {
		Scanner sc =  new Scanner(System.in);
		System.out.println("Introduce letra del dia de la semana: ");
		String dia = sc.next();
		
		switch (dia.toUpperCase()) {
			case "l":
			case "L":
				System.out.println("Es lunes");
				break;
		
			case "M":
				System.out.println("Es martes");
				break;
	
			case "X":
				System.out.println("Es miercoles");
				break;
	
			case "J":
				System.out.println("Es jueves");
				break;
	
			case "V":
				System.out.println("Es viernes");
				break;
	
			case "S":
				System.out.println("Es sabado");
				break;
	
			case "D":
				System.out.println("Es domingo");
				break;
				
			default:
				System.out.println("Dia no valido");			
		}
		
		sc.close();

	}

}
