package com.telefonica;
 
// En Java, cuando utilizo clases de otros paquetes hay que importarlas
import com.telefonica.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Empleado empleado1 = new Empleado("Juan", 37, 1, 45000);
		Empleado empleado2 = new Empleado("Juan", 37, 1, 45000);
		System.out.println(empleado1);
		
		// El operador == compara el contenido de las variables
		// funciona bien con tipos primitivos
		// en el caso de los objetos, compara direcciones de memoria
		System.out.println("Son iguales? " + (empleado1 == empleado2));
		
		System.out.println("Son iguales? " + empleado1.equals(empleado2));
		
	}

}
