package com.telefonica;
 
import com.telefonica.models.Direccion;
// En Java, cuando utilizo clases de otros paquetes hay que importarlas
import com.telefonica.models.*;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear objetos o instancias de Empleado
		com.telefonica.models.Empleado empleado1 =  new Empleado();
		empleado1.numEmpleado = 1;
		empleado1.nombre = "Juan";
		empleado1.sueldo = 54000;
		
		Direccion dir = new Direccion("Mayor", 62, "Madrid");
		empleado1.direccion = dir;
		
		
		empleado1.mostrarDetalle();
		System.out.println(empleado1.verNombre());
		empleado1.cambiarSueldo(56000);
		empleado1.mostrarDetalle();
		
		Empleado empleado2 = new Empleado(2, "Maria", 63000, new Direccion("Diagonal", 41, "Barcelona"));
		empleado2.mostrarDetalle();
		
	}

}
