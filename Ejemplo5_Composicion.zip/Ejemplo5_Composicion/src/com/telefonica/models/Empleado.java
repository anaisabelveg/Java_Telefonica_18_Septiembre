package com.telefonica.models;

public class Empleado {
	
	// propiedades, caracteristicas, atributos, campos
	public int numEmpleado;
	public String nombre;
	public double sueldo;
	public Direccion direccion;
	
	// Constructor por defecto
	// El compilador, en el momento de la compilacion, comprueba si existe algun constructor
	// si no existe ninguno, añade el contructor por defecto
	public Empleado() {
		// TODO Auto-generated constructor stub
	}
	
	// Constructor completo
	public Empleado(int numEmpleado, String nombre, double sueldo, Direccion direccion) {
		super();
		this.numEmpleado = numEmpleado;
		this.nombre = nombre;
		this.sueldo = sueldo;
		this.direccion = direccion;
	}

	// Metodos, funciones, acciones
	public void mostrarDetalle() {
		System.out.println("Numero: " + numEmpleado + " Nombre: " + nombre + 
				" Sueldo: " + sueldo + " Direccion: " + direccion.mostrar());
		System.out.printf("Numero: %d  Nombre: %s Sueldo: %.2f Direccion: %s %n", 
				numEmpleado, nombre, sueldo, direccion.mostrar());
	}
	
	public String verNombre() {
		return nombre;
	}
	
	public void cambiarSueldo(double nuevo) {
		sueldo = nuevo;
	}

}
