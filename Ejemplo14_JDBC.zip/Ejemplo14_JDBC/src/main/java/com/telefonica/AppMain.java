package com.telefonica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.telefonica.models.Producto;
import com.telefonica.persistence.ProductosDAO;

@SpringBootApplication
public class AppMain {

	public static void main(String[] args) {
		SpringApplication.run(AppMain.class, args);
		
		
		ProductosDAO dao = new ProductosDAO();
		
		System.out.println("------- Todos los productos -------");
		for(Producto p : dao.consultarTodos()) {
			System.out.println(p);
		}
		
		System.out.println("------ Buscar un producto --------");
		System.out.println(dao.buscarProducto(3));
	}

}
