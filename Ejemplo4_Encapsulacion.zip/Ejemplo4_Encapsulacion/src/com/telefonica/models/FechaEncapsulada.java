package com.telefonica.models;

// Una clase encapsulada, tiene todas sus propiedades declaradas como privadas
// y solo se accede a ellas a través de los métodos get y set publicos
public class FechaEncapsulada {
	
	private int dia;
	private int mes;
	private int anyo;
	
	public void mostrar() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

	// Metodo de lectura
	public int getDia() {
		return dia;
	}

	// Metodo de escritura
	public void setDia(int dia) {
		if (dia > 0 && dia <= 31) {
			this.dia = dia;
		}	
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12)
			this.mes = mes;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo == 2023 || anyo == 2024)
			this.anyo = anyo;
	}

}
