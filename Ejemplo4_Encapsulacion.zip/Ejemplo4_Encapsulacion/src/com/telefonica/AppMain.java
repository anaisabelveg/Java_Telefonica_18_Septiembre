package com.telefonica;

import com.telefonica.models.Fecha;
import com.telefonica.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 18;
		fecha.mes = 9;
		fecha.anyo = 2023;
		fecha.mostrar();
		
		Fecha fechaErronea = new Fecha();
		fechaErronea.dia = -456;
		fechaErronea.mes = 12334;
		fechaErronea.anyo = -9876;
		fechaErronea.mostrar();
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(187655);
		fechaEncapsulada.setMes(654);
		fechaEncapsulada.setAnyo(-321);
		fechaEncapsulada.mostrar();
		
		FechaEncapsulada hoy = new FechaEncapsulada();
		hoy.setDia(18);
		hoy.setMes(9);
		hoy.setAnyo(2023);
		hoy.mostrar();

	}

}
