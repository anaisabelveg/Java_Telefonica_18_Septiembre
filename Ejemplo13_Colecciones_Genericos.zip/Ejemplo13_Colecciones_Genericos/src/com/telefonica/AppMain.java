package com.telefonica;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		// Set: No permite duplicados y no garantiza el orden de entrada
		Set numeros = new HashSet();
		numeros.add(1);
		numeros.add("dos");
		numeros.add(new Integer(3));
		numeros.add(new Double(9.5667));
		numeros.add("dos");  // Ignora los repetidos
		
		for (Object object : numeros) {
			System.out.println(object);
		}
		
		// En Java 5 incluye los Genericos
		Set<Integer> numeros2 = new HashSet<Integer>();
		numeros2.add(1);
		//numeros2.add(3.14);
		numeros2.add(23);
		numeros2.add(7);
		
		for (Integer num : numeros2) {
			System.out.println(num);
		}
		
		// List: Si permiten duplicados, si garantiza el orden de entrada
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add("Juan");
		
		for (String nombre : nombres) {
			System.out.println(nombre);
		}
		
		// Map: los elementos son clave=valor. Las claves no se pueden duplicar y los value si.
		Map<String, Double> alumnos = new HashMap<String, Double>();
		alumnos.put("Juan", 9.3);
		alumnos.put("Maria", 7.8);
		alumnos.put("Pedro", 3.6);
		alumnos.put("Pedro", 5.5); // Se sobreescribe el valor
		
		System.out.println("Nombres: " + alumnos.keySet());
		System.out.println("Notas: " + alumnos.values());
		System.out.println("Entradas: " + alumnos.entrySet());

	}

}







