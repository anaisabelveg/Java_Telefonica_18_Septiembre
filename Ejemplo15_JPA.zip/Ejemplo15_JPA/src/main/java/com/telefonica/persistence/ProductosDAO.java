package com.telefonica.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.telefonica.models.Producto;

public class ProductosDAO {
	
	private EntityManagerFactory emf;
	
	public ProductosDAO() {
		emf = Persistence.createEntityManagerFactory("PU");
	}
	
	public List<Producto> consultarTodos(){
		EntityManager em = emf.createEntityManager();
		Query query = em.createQuery("select p from Producto p");
		return query.getResultList();
	}
	
	public Producto buscarProducto(int ID){
		EntityManager em = emf.createEntityManager();
		return em.find(Producto.class, ID);
	}
	
	public void altaProducto(Producto nuevo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			em.persist(nuevo);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		}
	}
	
	
}
