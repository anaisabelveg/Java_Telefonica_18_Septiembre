package com.telefonica;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class AppMain {

	public static void main(String[] args) {
		
		// LocalDate
		System.out.println(LocalDate.now());
		System.out.println(LocalDate.of(2023, 5, 30));
		System.out.println(LocalDate.now().isBefore(LocalDate.of(2023, 5, 30)));
		System.out.println(LocalDate.now().isAfter(LocalDate.of(2023, 5, 30)));
		System.out.println(LocalDate.now().isLeapYear());
		System.out.println(LocalDate.now().getDayOfWeek());
		System.out.println(LocalDate.now().plusMonths(1));
		
		DateTimeFormatter miFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String hoy = LocalDate.now().format(miFormato);
		System.out.println(hoy);
		
		// LocalTime
		System.out.println(LocalTime.now());
		System.out.println(LocalTime.now().truncatedTo(ChronoUnit.MINUTES));
		System.out.println(LocalTime.now().plusHours(2).plusMinutes(30));
		System.out.println(LocalTime.now().isAfter(LocalTime.of(19, 30)));
		System.out.println(LocalTime.now().until(LocalTime.of(19, 00), ChronoUnit.MINUTES));
		System.out.println(LocalTime.now().toSecondOfDay());
		
		// LocalDateTime
		System.out.println(LocalDateTime.now());
		System.out.println(LocalDateTime.of(2023, 12, 25, 13, 30));
		System.out.println(LocalDateTime.of(LocalDate.of(2023, 12, 25), LocalTime.of(13, 30)));
		System.out.println(LocalDateTime.now().plusDays(3).plusHours(2));
		
	}

}
